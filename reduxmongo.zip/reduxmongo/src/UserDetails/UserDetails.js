import React,{Component} from 'react'
import TextField from '@material-ui/core/TextField'
import Button from '@material-ui/core/Button'
import SaveIcon from '@material-ui/icons/Save'
import axios from 'axios'
export class UserDetails extends Component{

    constructor(props)
    {
        super(props)
        console.log(props);
    }

    state={

        name:'',
        email:'',
        user:this.props.user
    }

    changeHandller=(event)=>{
        this.setState({user:event.target.value});
        console.log(this.state.user);
    }

    submit=(e)=>{
        e.preventDefault();
        console.log(this.state.user);
        let reqData=this.state.user;
        axios.post(`https://jsonplaceholder.typicode.com/users`, { reqData })
            .then(res => {
                console.log(res);
                console.log(res.data);
            })

     }

     componentWillReceiveProps(nextProps)
     {
         console.log('[UserDetails.js] will receive props', nextProps);

     }

     shouldComponentUpdate(nextProps,nextState)
     {
         console.log('[UserDetails.js] will update',nextProps,nextState)
         return true;
     }


    render()
    {
        return(
            <div>
             <form onSubmit={this.submit}>
                 <TextField  fullWidth margin="dense" label="Name" name="name"
                            value={this.state.user.name} onChange={this.changeHandller} />
                 <TextField  fullWidth margin="dense" label="Email"
                            name="email" value={this.state.user.email} onChange={this.changeHandller}/>
                 <Button type="submit" color="primary">
                     <SaveIcon/>

                 </Button>
             </form>
            </div>
        )
    }


}
