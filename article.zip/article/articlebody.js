import React from 'react';
import PropTypes from 'prop-types';
const ArticleBody = ({ body }) => (
    <div>
        <p>{body}</p>
    </div>
);

ArticleBody.propTypes = {
    body: PropTypes.string.isRequired,
}

export default ArticleBody;