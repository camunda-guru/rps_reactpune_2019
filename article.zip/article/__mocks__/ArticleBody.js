import React from 'react';

const ArticleBody = props => (
  <span>ArticleBody {JSON.stringify(props)}</span>
);

module.exports = ArticleBody;
