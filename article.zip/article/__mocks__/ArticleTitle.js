import React from 'react';

const ArticleTitle = props => (
  <span>ArticleTitle {JSON.stringify(props)}</span>
);

module.exports = ArticleTitle;
